package com.cg.spring.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name="MyCustomer")
public class Customer 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int customerId;
	
	
	
	@NotEmpty(message="First Name can not Be Null")
	@Pattern(regexp="[A-Z][a-z]{4,}",message="Name Should Contain Only Alphbate")
	private String username;

	private String password;
	

	private String gen;
	

	private String city;
	private String mobile;
	private String email;
	
	public Customer() 
	{
		super();
	}
	
	
	
	
	public int getCustomerId() {
		return customerId;
	}
	
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getGen() {
		return gen;
	}
	public void setGen(String gen) {
		this.gen = gen;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Override
	public String toString() {
		return "Customer [username=" + username + ", password=" + password + ", gen=" + gen + ", city=" + city
				+ ", mobile=" + mobile + ", email=" + email + "]";
	}
	
	
	
}
