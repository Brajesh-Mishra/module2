package com.cg.spring.dao;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.spring.bean.Customer;


@Repository
@Transactional
public interface ICustomerRepo {

	public Customer addCustomer(Customer customer);

	public ArrayList<Customer> getAllCustomer();
}
