package com.cg.spring.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.spring.bean.Customer;

@Repository
public class Dao implements ICustomerRepo{

	@PersistenceContext
	EntityManager entity;
	
	public EntityManager getEntity() {
		return entity;
	}




	public void setEntity(EntityManager entity) {
		this.entity = entity;
	}




	@Override
	public Customer addCustomer(Customer customer) {
	
		entity.persist(customer);
		entity.flush();
		return customer;
	}




	@Override
	public ArrayList<Customer> getAllCustomer() {
	
		Query query=entity.createQuery("select e from Customer e");
		return (ArrayList<Customer>) query.getResultList();
		
	}
	
	

}
