package com.cg.spring.mvcdemo;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.spring.bean.Customer;
import com.cg.spring.service.ICustomerServ;

@Controller
public class HomeController {

	
	@Autowired
	ICustomerServ service;
	
	
	
		@RequestMapping("/homepage")
		public String displayWelcomePage()
		{
//			ModelAndView mv = new ModelAndView();
//			mv.addObject("",  date);
//			mv.setViewName("Home");
			//ModelAndView mv= new ModelAndView("Welcome");
			return "Welcome";
		}
		
		@RequestMapping("/showRegistrationForm")
		public String showRegistrationForm(Model model)
		{
			Customer customer = new Customer();
			model.addAttribute("customer", customer);
			return "Login";
		}
		
//		public ModelAndView displayRegisterPage(@RequestParam("username")String name,
//				                                @RequestParam("password")String password,
//												@RequestParam("gen")String gender,
//												@RequestParam("city")String city,
//												@RequestParam("mobile")String mobile,
//												@RequestParam("email")String email)
//		{
//			ModelAndView mv= new ModelAndView();
//			mv.addObject("username",name);
//			mv.addObject("password",password);
//			mv.addObject("gen",gender);
//			mv.addObject("city",city);
//			mv.addObject("mobile",mobile);
//			mv.addObject("email",email);
//			mv.setViewName("successful");
//			return mv;
//		}
//		public String displayRegisterPage(@RequestParam("username")String name,
//                @RequestParam("password")String password,
//				@RequestParam("gen")String gender,
//				@RequestParam("city")String city,
//				@RequestParam("mobile")String mobile,
//				@RequestParam("email")String email,Model model)
//		{
//			model.addAttribute("username",name);
//			model.addAttribute("password",password);
//			model.addAttribute("gen",gender);
//			model.addAttribute("city",city);
//			model.addAttribute("mobile",mobile);
//			model.addAttribute("email",email);
//			return "successful";
//		}
		
		@RequestMapping("/Register")
		public String RegisterCustomerDetails(@Valid @ModelAttribute("customer")Customer customer,BindingResult result,Model model)
		{
			if(result.hasErrors())
				return "Login";
			
			customer=service.addCustomer(customer);
			model.addAttribute("customer", customer);
			return "successful";
		}

		@RequestMapping("/list")
		public String getEmpList(Model model)
		{
			ArrayList<Customer> list=service.getAllCustomer();
			model.addAttribute("list", list);
			return "list";
		}
}
