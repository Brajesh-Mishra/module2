package com.cg.spring.service;

import java.util.ArrayList;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.spring.bean.Customer;


@Service
@Transactional
public interface ICustomerServ {
	
	public Customer addCustomer(Customer customer);
	public ArrayList<Customer> getAllCustomer();

}
