package com.cg.spring.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.spring.bean.Customer;
import com.cg.spring.dao.ICustomerRepo;


@org.springframework.stereotype.Service
@Transactional
public class Service implements  ICustomerServ{

	
	
	@Autowired
	ICustomerRepo repo;
	
	
	
	public ICustomerRepo getRepo() {
		return repo;
	}



	public void setRepo(ICustomerRepo repo) {
		this.repo = repo;
	}



	@Override
	public Customer addCustomer(Customer customer) {
		
		
		return repo.addCustomer(customer);
	}



	@Override
	public ArrayList<Customer> getAllCustomer() {
		return repo.getAllCustomer();
	}

}
