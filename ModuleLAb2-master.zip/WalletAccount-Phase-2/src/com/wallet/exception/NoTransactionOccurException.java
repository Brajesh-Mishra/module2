package com.wallet.exception;

public class NoTransactionOccurException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "No Transaction Occur Exception";
	}

}
